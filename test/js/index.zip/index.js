// js1

// for (var num = 1; num <= 1000; num++) {
//     var isEven = num % 2 === 0;
//     var result = isEven ? num + " juft son." : num + " toq son.";
//     console.log(result);
// }



// js2

// var grade = 40;
// var result = (grade >= 90) ? "A" :
//              (grade >= 80) ? "B" :
//              (grade >= 70) ? "C" :
//              (grade >= 60) ? "D" :
//              "Failed";

// console.log(result);

// js3

// var fruit = "tomato";
// var fruitPrice = 10000;
// var result = (fruit === "apple") ?
//              (fruitPrice >= 10000) ? "apple" :
//              (fruitPrice >= 12000) ? "pear" :
//              (fruitPrice >= 20000) ? "watermelon" :
//              "Not available" :
//              "Invalid fruit";
            
// console.log(result);

// js4

// var num = 13;
// var divisibleBy3 = num % 3 === 0;
// var divisibleBy5 = num % 5 === 0;

// var result = divisibleBy3 ? "3 ga bo`linadi" :
//              divisibleBy5 ? "5 ga bo`linadi":
//              (divisibleBy3 && divisibleBy5) ? " 3ga va 5ga bo`linadi" :
//              "3ga va 5ga bo`linmaydi";

// console.log(result);


